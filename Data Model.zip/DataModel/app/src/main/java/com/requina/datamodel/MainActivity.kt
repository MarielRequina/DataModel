package com.requina.datamodel

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.requina.datamodel.Movie
import com.requina.datamodel.R
import com.requina.datamodel.TmdbApiService
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MainActivity : AppCompatActivity() {

    private val tmdbApiService = createTmdbApiService()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Find the RecyclerView by its ID
        val recyclerView = findViewById<RecyclerView>(R.id.recyclerView)

        // Set up the RecyclerView
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Make API call for popular movies
        fetchPopularMovies()
    }


    private fun fetchPopularMovies() {
        val apiKey = "your_api_key_here" // Replace with your actual TMDB API key
        val popularMoviesCall = tmdbApiService.getPopularMovies(apiKey)

        // Enqueue the call asynchronously
        popularMoviesCall.enqueue(object : Callback<List<Movie>> {
            override fun onResponse(call: Call<List<Movie>>, response: Response<List<Movie>>) {
                if (response.isSuccessful) {
                    val movies = response.body()
                    // Process the list of movies
                    // Update your UI or perform other operations
                } else {
                    // Handle error
                    val errorMessage = "Error: ${response.code()} ${response.message()}"
                    // Display errorMessage to the user or handle it in a meaningful way
                }
            }

            override fun onFailure(call: Call<List<Movie>>, t: Throwable) {
                // Handle network failure
                // Display an error message or retry the request
            }
        })
    }

    private fun createTmdbApiService(): TmdbApiService {
        val retrofit = Retrofit.Builder()
            .baseUrl("https://api.themoviedb.org/3/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()

        return retrofit.create(TmdbApiService::class.java)
    }
}
