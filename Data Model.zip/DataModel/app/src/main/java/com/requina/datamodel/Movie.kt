package com.requina.datamodel

data class Movie(
    val title: String,
    val posterImageUrl: String,
    val overview: String,
    val rating: Double
)

